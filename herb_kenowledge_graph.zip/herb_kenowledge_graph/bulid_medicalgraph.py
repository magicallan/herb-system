import os
import csv
from py2neo import Graph, Node


class MedicalGraph:
    def __init__(self):
        cur_dir = '/'.join(os.path.abspath(__file__).split('/')[:-1])
        self.pre_path = {
            'herbTable': os.path.join(cur_dir, 'pre_csv/herbTable.csv'),
            'channel_belong': os.path.join(cur_dir, 'pre_csv/channel_belong_to.csv'),
            'class_belong': os.path.join(cur_dir, 'pre_csv/class_belong_to.csv'),
            'has_effect': os.path.join(cur_dir, 'pre_csv/has_effect.csv'),
            'has_flavor': os.path.join(cur_dir, 'pre_csv/has_flavor.csv'),
            'has_property': os.path.join(cur_dir, 'pre_csv/has_property.csv'),
            'herb_belong': os.path.join(cur_dir, 'pre_csv/herb_belong_to.csv'),
            'used_for': os.path.join(cur_dir, 'pre_csv/ued_for.csv'),
            'medicament': os.path.join(cur_dir, 'pre_csv/medicament.csv'),
            'medicament_contain': os.path.join(cur_dir, 'pre_csv/medicament_contain.csv'),
            'medicament_heal': os.path.join(cur_dir, 'pre_csv/medicament_heal.csv'),
            'class1': os.path.join(cur_dir, 'pre_csv/class1.csv'),
            'class2': os.path.join(cur_dir, 'pre_csv/class2.csv'),
            'flavor': os.path.join(cur_dir, 'pre_csv/flavor.csv'),
            'channel': os.path.join(cur_dir, 'pre_csv/channel.csv'),
            'property': os.path.join(cur_dir, 'pre_csv/property.csv'),
            'disease': os.path.join(cur_dir, 'pre_csv/disease.csv'),
            'heal_by': os.path.join(cur_dir, 'pre_csv/heal_by.csv'),
            'consist_of': os.path.join(cur_dir, 'pre_csv/consist_of.csv'),
            'formula': os.path.join(cur_dir, 'pre_csv/formula.csv'),
            'formula_consist': os.path.join(cur_dir, 'pre_csv/formula_consist.csv'),
            'formula_deal': os.path.join(cur_dir, 'pre_csv/formular_to_deal.csv'),
            'dealed': os.path.join(cur_dir, 'pre_csv/dealed.csv'),
            'dealed_by_formular': os.path.join(cur_dir, 'pre_csv/dealed_by_formular.csv'),
        }
        self.g = Graph("bolt://localhost:7690", auth=('neo4j', "12345678"))
        self.g.run('match (n) detach delete n')

    def read_data(self, if_rels):
        def read_csv(file_name):
            with open(file_name, 'r', encoding='utf-8') as f:
                csvreader = csv.reader(f)
                final_list = list(csvreader)
            return final_list

        # 读取节点列表
        _herbTable = read_csv(self.pre_path['herbTable'])
        _medicaments = read_csv(self.pre_path['medicament'])
        _class1 = read_csv(self.pre_path['class1'])
        _class2 = read_csv(self.pre_path['class2'])
        _property = read_csv(self.pre_path['property'])
        _flavor = read_csv(self.pre_path['flavor'])
        _channel = read_csv(self.pre_path['channel'])
        _disease = read_csv(self.pre_path['disease'])
        _formula = read_csv(self.pre_path['formula'])
        _dealed = read_csv(self.pre_path['dealed'])
        # 读取边关系列表
        _el_channel = read_csv(self.pre_path['channel_belong'])
        _el_class = read_csv(self.pre_path['class_belong'])
        _el_property = read_csv(self.pre_path['has_property'])
        _el_flavor = read_csv(self.pre_path['has_flavor'])
        _el_herb_belong = read_csv(self.pre_path['herb_belong'])
        _el_contain = read_csv(self.pre_path['medicament_contain'])
        _el_heal = read_csv(self.pre_path['medicament_heal'])
        _heal_by = read_csv(self.pre_path['heal_by'])
        _consist_of = read_csv(self.pre_path['consist_of'])
        _formula_consist = read_csv(self.pre_path['formula_consist'])
        _formula_deal = read_csv(self.pre_path['formula_deal'])
        _dealed_by_formular = read_csv(self.pre_path['dealed_by_formular'])
        if if_rels:
            return _el_class, _el_herb_belong, _el_flavor, _el_property, _el_channel, _el_contain, _el_heal, _heal_by, \
                   _consist_of, _formula_consist, _formula_deal, _dealed_by_formular
        else:
            return _herbTable, _medicaments, _class1, _class2, _property, _flavor, _channel, _disease, _formula, _dealed

    '''创立节点'''

    def create_node(self, label, nodes):
        count = 0
        for node_name in nodes:
            node = Node(label, name=node_name[0])
            self.g.create(node)
            count += 1
            print(count, len(nodes))
        return

    '''创建中心中草药的节点'''

    def create_herb_nodes(self, herbTable):
        count = 0
        for herb in herbTable:
            node = Node("herb", name=herb[0], alias=herb[2], english_name=herb[3],
                        morphology=herb[6], distribution=herb[7], processing=herb[8],
                        Type=herb[10], effect=herb[11], taboo=herb[16])
            self.g.create(node)
            count += 1
            print(count)
        return

    '''建立药剂节点'''

    def create_medicament(self, medicaments):
        count = 0
        for medicament in medicaments:
            node = Node('medicament', name=medicament[0], contains=medicament[1], heal_for=medicament[2])
            self.g.create(node)
            count += 1
            print(count)
        return

    '''建立配方节点'''

    def create_formula(self, formulas):
        count = 0
        for formula in formulas:
            node = Node('formula', name=formula[0], description=formula[1], consist=formula[2])
            self.g.create(node)
            count += 1
            print(count)
        return

    '''构建知识图的实体节点'''

    def create_graph_nodes(self):
        herbTable, medicaments, class1, class2, property, flavor, channel, disease, formular, dealed = b.read_data(
            if_rels=False)
        self.create_herb_nodes(herbTable)
        self.create_medicament(medicaments)
        self.create_formula(formular)
        self.create_node('class1', class1)
        print(len(class1))
        self.create_node('class2', class2)
        print(len(class2))
        self.create_node('property', property)
        print(len(property))
        self.create_node('flavor', flavor)
        print(len(flavor))
        self.create_node('channel', channel)
        print(len(channel))
        self.create_node('disease', disease)
        print(len(disease))
        self.create_node('dealed', dealed)
        print(len(dealed))

    def create_relationship(self, start_node, end_node, edges, rel_type, rel_name):
        count = 0
        set_edges = []
        for edge in edges:
            set_edges.append('###'.join(edge))
        all = len(set(set_edges))
        for edge in set(set_edges):
            edge = edge.split('###')
            p = edge[0]
            q = edge[1]
            query = "match(p:%s),(q:%s) where p.name='%s' and q.name='%s' create (p)-[rel:%s{name:'%s'}]->(q)" % (
                start_node, end_node, p, q, rel_type, rel_name)
            try:
                self.g.run(query)
                count += 1
                print(rel_type, count, all)
            except Exception as e:
                print(e)
        return

    def create_graph_rels(self):
        el_class, el_herb_belong, el_flavor, el_property, el_channel, el_contain, el_heal, heal_by, consist_of, formula_consist, formula_deal, dealed_by_formular = b.read_data(
            if_rels=True)
        self.create_relationship('herb', 'flavor', el_flavor, 'has_flavor', '有_味')
        self.create_relationship('herb', 'property', el_property, 'has_property', '有_性')
        self.create_relationship('herb', 'channel', el_channel, 'channel_local', '位于_经')
        self.create_relationship('medicament', 'herb', el_contain, 'contain', '包含')
        self.create_relationship('herb', 'medicament', consist_of, 'consist_of', '组成')
        self.create_relationship('medicament', 'disease', el_heal, 'heal_for', '医治')
        self.create_relationship('disease', 'medicament', heal_by, 'be_healed', '被医治于')
        self.create_relationship('formula', 'herb', formula_consist, 'formula_consist', '(配方)包含')
        self.create_relationship('formula', 'dealed', formula_deal, 'formula_deal', '(配方)用于')
        self.create_relationship('dealed', 'formula', dealed_by_formular, 'dealed_by_formular', '被(配方)医治')
        self.create_relationship('class2', 'class1', el_class, 'class_belong_to', '属于_类I')
        self.create_relationship('herb', 'class2', el_herb_belong, 'herb_belong_to', '属于_类II')


if __name__ == '__main__':
    b = MedicalGraph()
    b.create_graph_nodes()
    b.create_graph_rels()
