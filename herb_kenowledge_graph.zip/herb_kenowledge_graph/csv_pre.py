import csv

# with open('pre_csv/ued_for.csv', 'a+', encoding='utf-8') as f_pre:
#     writer = csv.writer(f_pre)
#     with open('./data_csv/处理.csv', encoding='utf-8') as f:
#         csv_reader = csv.reader(f)
#         for line in csv_reader:
#             s = line[1].split(',')
#             print(s)
#             for k in range(len(s)):
#                 f_pre.write(s[k].strip() + ',' + line[0] + ',' + "used_for" + '\n')
#
# with open('pre_csv/channel_belong_to.csv', 'a+', encoding='utf-8') as f_pre:
#     with open('./data_csv/草药归经.csv', encoding='utf-8') as f:
#         csv_reader = csv.reader(f)
#         for line in csv_reader:
#             s = line[1].split('、')
#             print(s)
#             for k in range(len(s)):
#                 f_pre.write(line[0] + ',' + s[k].strip() + ',' + "channel_belong_to" + '\n')
#
# with open('pre_csv/class_belong_to.csv', 'a+', encoding='utf-8') as f_pre:
#     with open('./data_csv/中药分类.csv', encoding='utf-8') as f:
#         csv_reader = csv.reader(f)
#         for line in csv_reader:
#             f_pre.write(line[0] + ',' + line[2] + ',' + "class_belong_to" + '\n')
#
# with open('pre_csv/has_effect.csv', 'a+', encoding='utf-8') as f_pre:
#     with open('./data_csv/草药功效.csv', encoding='utf-8') as f:
#         csv_reader = csv.reader(f)
#         for line in csv_reader:
#             f_pre.write(line[0] + ',' + line[1] + ',' + "has_effect" + '\n')
#
# with open('pre_csv/has_property.csv', 'a+', encoding='utf-8') as f_pre1:
#     with open('./data_csv/has_flavor.csv', 'a+', encoding='utf-8') as f_pre2:
#         with open('草药性味.csv', encoding='utf-8') as f:
#             csv_reader = csv.reader(f)
#             for line in csv_reader:
#                 f_pre1.write(line[0] + ',' + line[1].strip() + ',' + "has_property" + '\n')
#                 s = line[2].split('、')
#                 for k in range(len(s)):
#                     f_pre2.write(line[0] + ',' + s[k].strip() + ',' + "has_flavor" + '\n')
#
# with open('pre_csv/herb_belong_to.csv', 'a+', encoding='utf-8') as f_pre:
#     with open('./data_csv/草药分类.csv', encoding='utf-8') as f:
#         csv_reader = csv.reader(f)
#         for line in csv_reader:
#             f_pre.write(line[0] + ',' + line[1] + ',' + "herb_belong_to" + '\n')
#
# with open('pre_csv/medicament_contain.csv', 'a+', encoding='utf-8') as f_pre:
#     writer = csv.writer(f_pre)
#     with open('data_csv/药剂.csv', encoding='utf-8') as f:
#         csv_reader = csv.reader(f)
#         for line in csv_reader:
#             s = line[1].split(',')
#             print(s)
#             for k in range(len(s)):
#                 f_pre.write(line[0] + ',' + s[k].strip() + ',' + "medicament_contain" + '\n')
#
# with open('pre_csv/medicament_heal.csv', 'a+', encoding='utf-8') as f_pre:
#     writer = csv.writer(f_pre)
#     with open('data_csv/药剂.csv', encoding='utf-8') as f:
#         csv_reader = csv.reader(f)
#         for line in csv_reader:
#             s = line[2].split(',')
#             print(s)
#             for k in range(len(s)):
#                 f_pre.write(line[0] + ',' + s[k].strip() + ',' + "medicament_heal" + '\n')

with open('pre_csv/formula.csv', 'a+', encoding='utf-8') as f_pre1:
    with open('pre_csv/formula_consist.csv', 'a+', encoding='utf-8') as f_pre2:
        with open('data_csv/配方实体.csv', encoding='utf-8') as f:
            csv_reader = csv.reader(f)
            for line in csv_reader:
                f_pre1.write(line[0] + ',' + line[2].strip('\n') + ',' + '"' + line[1] + '"' + '\n')
                s = line[1].split(',')
                print(s)
                for k in range(len(s)):
                    f_pre2.write(line[0] + ',' + s[k].strip() + '\n')

